<form action="lib/productBasket.php" method="post"  value="Apple iPhone 14 Pro 512GB Gold (MQ233)">
    <!-- <input type="text" name="product" id="" value="Apple iPhone 14 Pro 512GB Gold (MQ233)"> -->
    <input type="submit" name="product" id="" value="Buy now" data_value="1">
    <!-- <button>Buy Now</button> -->
</form>