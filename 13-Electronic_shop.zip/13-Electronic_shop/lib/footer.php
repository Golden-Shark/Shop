    <footer>
        <div class="container">
            <div class="top">
                <div class="left">
                    <img src="<?=$linkImg?>LogoFooter.png" alt="">
                    <p>We are a residential interior design firm located in Portland. Our boutique-studio offers more than</p>
                </div>
                <div class="right">
                    <div class="block">
                        <h4>Services</h4>
                        <ul>
                            <li><a href="#">Bonus program</a></li>
                            <li><a href="#">Gift cards</a></li>
                            <li><a href="#">Credit and payment</a></li>
                            <li><a href="#">Service contracts</a></li>
                            <li><a href="#">Non-cash account</a></li>
                            <li><a href="#">Payment</a></li>
                        </ul>
                    </div>
                    <div class="block">
                        <h4>Assistance to the buyer</h4>
                        <ul>
                            <li><a href="#">Find an order</a></li>
                            <li><a href="#">Terms of delivery</a></li>
                            <li><a href="#">Exchange and return of goods</a></li>
                            <li><a href="#">Guarantee</a></li>
                            <li><a href="#">Frequently asked questions</a></li>
                            <li><a href="#">Terms of use of the site</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="bottom">
                <div class="socialIcons">
                    <img src="<?=$linkImg?>Twitter.png" alt="" title="Twitter">
                    <img src="<?=$linkImg?>Facebook.png" alt="" title="Facebook">
                    <img src="<?=$linkImg?>Tiktok.png" alt="" title="TikTok">
                    <img src="<?=$linkImg?>Instagram.png" alt="" title="Instagram">
                </div>
            </div>
        </div>
    </footer>
    
    <?php echo $linkJS;?>
</body>
</html>