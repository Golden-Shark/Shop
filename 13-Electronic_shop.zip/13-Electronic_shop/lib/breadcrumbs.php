
<div class="breadcrumbs container">
    <div class="content">
        <a href="<?=$linkHome?>">Home</a>
        <img src="<?=$linkImg?>ArrowBreadcrumbs.png" alt="">
        <a href="../page/catalog.php">Catalog</a>
        <img src="../img/ArrowBreadcrumbs.png" alt="">
        <a href="#" class="active-breadcrumbs"><?=$nameProduct?></a>
    </div>
</div>