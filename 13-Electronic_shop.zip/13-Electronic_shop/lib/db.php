<?php
//Подключение к базе данных
$pdo = new PDO('mysql:host=localhost; dbname=electronic_shop;port=3306', 'root', '');

function database() {
    global $sql;
    $pdo = new PDO('mysql:host=localhost; dbname=electronic_shop;port=3306', 'root', '');
    $query = $pdo->prepare($sql);
    $query->execute();
    $productsArray = $query->fetchAll(PDO::FETCH_OBJ);
}