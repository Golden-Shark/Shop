<?php

session_start();

require "db.php";

$_SESSION = array();
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'delete':
            setcookie('arrayProducts['.$_GET['id'].']', $_GET['name'], time() - 3600, '/');
            setcookie('countProduct['.$_GET['id'].']', $_GET['count'], time() - 3600, '/');
            header('Location: ../page/basket.php');
            exit;
            break;
        case 'add':
            setcookie('arrayProducts['.$_GET['id'].']', $_GET['name'], 0, '/');
            setcookie('countProduct['.$_GET['id'].']', $_GET['count'], 0, '/');
            header('Location: ../page/catalog.php');
            exit;
            break;
        case 'reduceCount':
            if ($_COOKIE['countProduct'][$_GET['id']] == 1) {
                setcookie('arrayProducts['.$_GET['id'].']', $_GET['name'], time() - 3600, '/');
                setcookie('countProduct['.$_GET['id'].']', $_GET['count'], time() - 3600, '/');
            } else {
                $n = $_COOKIE['countProduct'][$_GET['id']] - 1;
                setcookie('countProduct['.$_GET['id'].']', $n, 0, '/');
            }
            header('Location: ../page/basket.php');
            exit;
            break;
        case 'increaseCount':
            $n = $_COOKIE['countProduct'][$_GET['id']] + 1;
            setcookie('countProduct['.$_GET['id'].']', $n, 0, '/');
            header('Location: ../page/basket.php');
            exit;
            break;
    }
}

$listSorting = array('Price increase', 'Price reduce');

if (isset($_GET['valueSort'])) {
    $sort = $_GET['valueSort'];
} else {
    $sort = 0;
}

switch($sort) {
    case 0:
        unset($_SESSION['currentSort']);
        header('Location: ../page/catalog.php');
        exit;
        break;
    case 1:
        $_SESSION['currentSort'] = $listSorting[0];
        header('Location: ../page/catalog.php');
        exit;
        break;
    case 2:
        $_SESSION['currentSort'] = $listSorting[1];
        header('Location: ../page/catalog.php');
        exit;
        break;
}

$sql = 'SELECT * FROM products';
$query = $pdo->prepare($sql);
$query->execute();
$productsArray = $query->fetchAll(PDO::FETCH_OBJ);

$newProductsArray = array_chunk($productsArray, 9);

/*if (isset($_GET['changeAction'])) {
    switch($_GET['changeAction']) {
        case 'previous':
            $_SESSION['page'] -= 1;
            break;
            header('Location: ../page/catalog.php');
            exit;
        case 'next':
            $_SESSION['page'] += 1;
            break;
            header('Location: ../page/catalog.php');
            exit;
    }
} else {
    $_SESSION['page'] = 0;
}*/