<?php

session_start();

if (isset($_COOKIE['arrayProducts'])) {
    $countProducts = count($_COOKIE['arrayProducts']);
} else {
    $countProducts = 0;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=$namePage;?></title>
    <?php echo $linkCss; ?>
</head>
<body>
    <header>
        <div class="head-menu container">
            <div class="logo">
                <img src="<?=$linkImg?>Logo.png" alt="">
            </div>
            <form action="" method="post" class="search">
                <button><img src="<?=$linkImg?>Search.png" alt="" title="Поиск"></button>
                <input type="text" name="search" id="" placeholder="Search">
            </form>
            <nav>
                <ul>
                    <li title="Главная"><a href="<?=$linkHome;?>" class="<?=$activePage['Home']?>">Home</a></li>
                    <li title="О нас"><a href="#" class="<?=$activePage['About']?>">About</a></li>
                    <li title="Контакты"><a href="#" class="<?=$activePage['Contact us']?>">Contact Us</a></li>
                    <li title="Каталог"><a <?=$linkCatalog;?> class="<?=$activePage['Catalog']?>">Catalog</a></li>
                </ul>
            </nav>
            <div class="icons">
                <a href="#"><img src="<?=$linkImg?>Favorites.png" alt="Избранное" title="Избранное"></a>
                <a href="<?=$linkBasket?>basket.php" class="productBasketLink">
                    <img src="<?=$linkImg?>Cart.png" alt="Корзина" title="Корзина">
                    <p><?=$countProducts?></p>
                </a>
                <a href="#"><img src="<?=$linkImg?>User.png" alt="Личный кабинет" title="Личный кабинет"></a>
            </div>
        </div>
    </header>