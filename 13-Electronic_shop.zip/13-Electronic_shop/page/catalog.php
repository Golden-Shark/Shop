<?php

$linkCss = '<link rel="stylesheet" href="../style.css">
<link rel="stylesheet" href="../css/catalog.css">';
$linkJS = '<script src="../js/catalog.js" type="text/javascript"></script>';
$linkCatalog = 'href="catalog.php"';
$linkHome = 'http://'.$_SERVER['HTTP_HOST'].'/13-Electronic_shop/index.php';
$linkHeader = '../lib/header.php';
$linkFooter = '../lib/footer.php';
$linkImg = '../img/';
$linkBasket = '';
$namePage = 'Каталог';
$activePage = array('Home' => '', 'About' => '', 'Contact us' => '', 'Catalog' => 'active',);

require_once "../lib/db.php";
require_once('../lib/header.php');
// require_once('../lib/breadcrumbs.php');

$sqlArray = array('SELECT * FROM products', 'SELECT * FROM products ORDER BY price ASC', 'SELECT * FROM products ORDER BY price DESC');

if (isset($_SESSION['currentSort'])) {
    $currentSort = $_SESSION['currentSort'];
} else {
    $currentSort = 'Sorting by';
}

switch ($currentSort) {
    case 'Price increase':
        $sql = $sqlArray[1]; 
        break;
    case 'Price reduce':
        $sql = $sqlArray[2];
        break;
    default:
        $sql = $sqlArray[0];
        break;
}

$query = $pdo->prepare($sql);
$query->execute();
$productsArray = $query->fetchAll(PDO::FETCH_OBJ);

if (isset($_GET['changeAction']) || !isset($_GET['pageNum'])) {
    switch($_GET['changeAction']) {
        case 'previous':
            $_SESSION['page'] -= 1;
            break;
            header('Location: ../page/catalog.php');
            exit;
        case 'next':
            $_SESSION['page'] += 1;
            break;
            header('Location: ../page/catalog.php');
            exit;
    }

} elseif (isset($_GET['pageNum'])) {
    $_SESSION['page'] = $_GET['pageNum'];
} else {
    $_SESSION['page'] = 0;
}

if (isset($_SESSION['page'])) {
    $page = $_SESSION['page'];
} else {
    $page = 0;
}

require "../function.php";
?>

    <div class="breadcrumbs container">
        <div class="content">
            <a href="<?=$linkHome?>" title="На главную">Home</a>
            <img src="../img/ArrowBreadcrumbs.png" alt="">
            <a href="#">Catalog</a>
            <img src="../img/ArrowBreadcrumbs.png" alt="">
            <a href="#" class="active-breadcrumbs">Smartphones</a>
        </div>
    </div>

    <div class="catalog container">
        <div class="filters">
            <div class="filter">
                <div class="head">
                    <h4>Brand</h4>
                    <img src="../img/expand_more.png" alt="" class="filterImg" onclick="openFilter(0)">
                </div>
                <div class="listFilters">
                    <ul>
                        <form action="../lib/productBasket.php" method="post">
                            <li><input type="checkbox" name="" id=""><p>Apple <span>110</span></p></li>
                            <li><input type="checkbox" name="" id=""><p>Samsung <span>125</span></p></li>
                            <li><input type="checkbox" name="" id=""><p>Xiaomi <span>68</span></p></li>
                            <li><input type="checkbox" name="" id=""><p>Poco <span>44</span></p></li>
                            <li><input type="checkbox" name="" id=""><p>OPPO <span>36</span></p></li>
                            <li><input type="checkbox" name="" id=""><p>Honor <span>10</span></p></li>
                            <li><input type="checkbox" name="" id=""><p>Motorola <span>34</span></p></li>
                            <li><input type="checkbox" name="" id=""><p>Nokia <span>22</span></p></li>
                            <li><input type="checkbox" name="" id=""><p>Realme <span>35</span></p></li>
                        </form>
                    </ul>
                </div>
            </div>
            <div class="filter">
                <div class="head">
                    <h4>Battery capacity</h4>
                    <img src="../img/expand_more.png" alt="" class="filterImg" onclick="openFilter(1)">
                </div>
                <div class="listFilters"></div>
            </div>
            <div class="filter">
                <div class="head">
                    <h4>Screen type</h4>
                    <img src="../img/expand_more.png" alt="" class="filterImg" onclick="openFilter(2)">
                </div>
                <div class="listFilters"></div>
            </div>
            <div class="filter">
                <div class="head">
                    <h4>Screen diagonal</h4>
                    <img src="../img/expand_more.png" alt="" class="filterImg" onclick="openFilter(3)">
                </div>
                <div class="listFilters"></div>
            </div>
            <div class="filter">
                <div class="head">
                    <h4>Protection class</h4>
                    <img src="../img/expand_more.png" alt="" class="filterImg" onclick="openFilter(4)">
                </div>
                <div class="listFilters"></div>
            </div>
            <div class="filter">
                <div class="head">
                    <h4>Built-in memory</h4>
                    <img src="../img/expand_more.png" alt="" class="filterImg" onclick="openFilter(5)">
                </div>
                <div class="listFilters"></div>
            </div>
        </div>
        <div class="products">
            <div class="top">
                <p>Selected Products: <span><?php echo count($productsArray); ?></span></p>
                <div class="changeSorting">
                    <div class="content">
                        <div class="active-sort">
                            <p class="text-sort"><?=$currentSort?></p>
                            <img class="openSort" title="Открыть сортировку" src="../img/ChevronDown.png" alt="">
                        </div>
                        <div class="listSorting">
                            <div class="sort" onclick="activeSort(0)">
                                <a href="../lib/productBasket.php?valueSort=0">Sorting by</a>
                            </div>
                            <div class="sort" onclick="activeSort(1)">
                                <a href="../lib/productBasket.php?valueSort=1">Price increase</a>
                            </div>
                            <div class="sort" onclick="activeSort(2)">
                                <a href="../lib/productBasket.php?valueSort=2">Price reduce</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="gridProducts">
                <?php
                downloadCatalog();
                ?>
            </div>
            <div class="navCatalog">
                <?php
                navCatalog();
                ?>
            </div>
        </div>
    </div>

<?php
require_once('../lib/footer.php');
?>