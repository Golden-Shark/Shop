<?php

require "../lib/db.php";


$sql = 'SELECT * FROM products';
$query = $pdo->prepare($sql);
$query->execute();
$productsArray = $query->fetchAll(PDO::FETCH_OBJ);

$linkCss = '<link rel="stylesheet" href="../style.css">
<link rel="stylesheet" href="../css/basket.css">';
$linkJS = '<script src="../js/catalog.js" type="text/javascript"></script>';
$linkCatalog = 'href="catalog.php"';
$linkHome = 'href="../index.php"';
$linkHeader = '../lib/header.php';
$linkFooter = '../lib/footer.php';
$linkImg = '../img/';
$linkBasket = '';
$namePage = 'Корзина';
$activePage = array('Home' => '', 'About' => '', 'Contact us' => '', 'Catalog' => '',);

require_once('../lib/header.php');
require "../function.php";
?>

    <div class="basket container">
        <div class="productBasket">
            <h2>Shopping Cart</h2>
            <div class="products">
                <?php

                $sumPrice = 0;
                $tax = 0;
                $shipping = 0;
                $m = 1;

                if (isset($_POST['promoCode'])) {
                    $promoCode = $_POST['promoCode'];
                    $sql = "SELECT * FROM promocode WHERE id LIKE '%$promoCode%'";
                    $query = $pdo->prepare($sql);
                    $query->execute();
                    $discount = $query->fetchAll(PDO::FETCH_OBJ);
                    foreach ($discount as $key) {
                        $m = $key->description/100;
                    }
                } 
                
                if (isset($_COOKIE['countProduct'])) {
                    foreach ($_COOKIE['countProduct'] as $key => $value) {
                        $countProduct[$key] = $value;
                    }
                } else {
                    $countProduct = array();
                }
                if (isset($_COOKIE['arrayProducts'])) {
                    foreach ($_COOKIE['arrayProducts'] as $key => $value) {
                        $articleProducts = htmlspecialchars($key);
                        $sql = "SELECT * FROM products WHERE article LIKE '%$articleProducts%'";
                        $query = $pdo->prepare($sql);
                        $query->execute();
                        $basket = $query->fetchAll(PDO::FETCH_OBJ);
                        foreach ($basket as $key) {
                            $sumPrice+=$key->price*$countProduct[$key->article];
                            echo '<div class="product">
                            <div class="img">
                                <img src="'.$key->img.'" alt="">
                            </div>
                            <div class="text">
                                <h5>'.$key->name.'</h5>
                                <p>'.$key->article.'</p>
                            </div>
                            <div class="count">
                               <a href="../lib/productBasket.php?action=reduceCount&id='.$key->article.'"><img src="../img/minus.png" alt=""></a>
                               <p>'.$countProduct[$key->article].'</p>
                               <a href="../lib/productBasket.php?action=increaseCount&id='.$key->article.'"><img src="../img/plus.png" alt=""></a>
                           </div>
                           <div class="price">
                               <h4>'.$key->price.'</h4>
                           </div>
                           <div class="delete">
                               <a href="../lib/productBasket.php?action=delete&id='.$key->article.'&name='.$key->name.'"><img src="../img/delete.png" title="Удалить из корзины" alt=""></a>
                           </div>
                        </div>';
                        }
                    }    
                } else { 
                    echo '<div class="nothingBasket">The basket is empty</div>';
                }
                
                $total = ($sumPrice + $shipping + $tax)*$m;
                ?>
            </div>
        </div>
        <div class="order">
            <h3>Order Summary</h3>
            <form action="basket.php" method="post">
                <label for="Promocode">Discount code / Promo code</label>
                <div class="promoCode">
                    <input type="text" name="promoCode" id="Promocode" placeholder="Code">
                    <button>Apply</button>
                </div>
                <label for="Bonus">Your bonus card number</label>
                <div class="bonusCard">
                    <input type="text" name="bonusCard" id="Bonus" placeholder="Enter Card Number">
                    <button>Apply</button>
                </div>
            </form>
            <div class="summary">
                <div class="subtotal">
                    <p>Subtotal</p>
                    <h4>$<?=$sumPrice?></h4>
                </div>
                <div class="tax">
                    <p>Estimated Tax</p>
                    <h4>$<?=$tax?></h4>
                </div>
                <div class="handing">
                    <p>Estimated shipping &amp; Handling</p>
                    <h4>$<?=$shipping?></h4>
                </div>
                <div class="total">
                    <p>Total</p>
                    <h4>$<?=$total?></h4>
                </div>
            </div>
            <form action="../lib/productBasket.php" method="post"><button class="sumBtn">Checkout</button></form>
        </div>
    </div>

<?php
require_once('../lib/footer.php');
?>