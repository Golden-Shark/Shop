<?php

require "../lib/db.php";
require "../function.php";

$linkCss = '<link rel="stylesheet" href="../css/cardProduct.css">';
$linkJS = '<script src="../js/cardProduct.js" type="text/javascript"></script>';
$linkCatalog = 'href="catalog.php"';
$linkHome = 'http://'.$_SERVER['HTTP_HOST'].'/13-Electronic_shop/index.php';
$linkImg = '../img/';
$linkBasket = '';
$namePage = 'Карточка товара';
$activePage = array('Home' => '', 'About' => '', 'Contact us' => '', 'Catalog' => '',);
$sqlArray = array('SELECT * FROM products', 'SELECT * FROM products ORDER BY price ASC', 'SELECT * FROM products ORDER BY price DESC');

if (isset($_GET)) {
    $nameProduct = $_GET['name'];
    $priceProduct = $_GET['price'];
} else {
    $nameProduct = '';
    $priceProduct = 0;
}

require_once('../lib/header.php');
require_once('../lib/breadcrumbs.php');
?>


    <!-- <div class="breadcrumbs container">
        <div class="content">
            <a href="../index.php">Home</a>
            <img src="../img/ArrowBreadcrumbs.png" alt="">
            <a href="../page/catalog.php">Catalog</a>
            <img src="../img/ArrowBreadcrumbs.png" alt="">
            <a href="#" class="active-breadcrumbs"><?=$nameProduct?></a>
        </div>
    </div> -->

    <div class="product container">
        <div class="slider">
            <div class="nav-slide">
                <div class="nav-photo active-photo">
                    <img src="../img/productPhoto1.png" alt="">
                </div>
                <div class="nav-photo">
                    <img src="../img/productPhoto2.png" alt="">
                </div>
                <div class="nav-photo">
                    <img src="../img/productPhoto3.png" alt="">
                </div>
                <div class="nav-photo">
                    <img src="../img/productPhoto4.png" alt="">
                </div>
            </div>
            <div class="main-photo">
                <img src="../img/productPhotoMain.png" alt="">
            </div>
        </div>
        <div class="description">
            <h1><?=$nameProduct?></h1>
            <h4>$<?=$priceProduct;?><span>$<?=$priceProduct+100;?></span></h4>
            <div class="select-color">
                <p>Select color:</p>
                <div class="colors">
                    <div class="color"><button class="black"></button></div>
                    <div class="color"><button class="violet"></button></div>
                    <div class="color"><button class="red"></button></div>
                    <div class="color"><button class="gold"></button></div>
                    <div class="color"><button class="white"></button></div>
                </div>
            </div>
            <div class="select-memory">
                <a href="#"><button class="product-not">128GB</button></a>
                <a href="#"><button>256GB</button></a>
                <a href="#"><button>512GB</button></a>
                <a href="#"><button class="active-btn">1TB</button></a>
            </div>
            <div class="characteristics">
                <div class="characteristic">
                    <img src="../img/Screensize.png" alt="">
                    <div class="content">
                        <p>Screen size<br><span>6.7"</span></p>
                    </div>
                </div>
                <div class="characteristic">
                    <img src="../img/CPU.png" alt="">
                    <div class="content">
                        <p>CPU<br><span>Apple A16 Bionic</span></p>
                    </div>
                </div>
                <div class="characteristic">
                    <img src="../img/numberCores.png" alt="">
                    <div class="content">
                        <p>Number of Cores<br><span>6</span></p>
                    </div>
                </div>
                <div class="characteristic">
                    <img src="../img/mainCamera.png" alt="">
                    <div class="content">
                        <p>Main camera<br><span>48-12 -12 MP</span></p>
                    </div>
                </div>
                <div class="characteristic">
                    <img src="../img/frontCamera.png" alt="">
                    <div class="content">
                        <p>Front-camera<br><span>12 MP</span></p>
                    </div>
                </div>
                <div class="characteristic">
                    <img src="../img/batteryCapacity.png" alt="">
                    <div class="content">
                        <p>Battery capacity<br><span>4323 mAh</span></p>
                    </div>
                </div>
            </div>
            <div class="information">
                <p>Enhanced capabilities thanks toan enlarged display of 6.7 inchesand work without rechargingthroughout the day. Incredible photosas in weak, yesand in bright lightusing the new systemwith two cameras more...</p>
            </div>
            <div class="btn-action">
                <a href="#"><button class="wishlist">Add to Wishlist</button></a>
                <a href="#"><button class="card">Add to Card</button></a>
            </div>
            <div class="other-info">
                <div class="block">
                    <img src="../img/Delivery.png" alt="">
                    <div class="content">
                        <h6>Free Delivery</h6>
                        <p>1-2 day</p>
                    </div>
                </div>
                <div class="block">
                    <img src="../img/Stock.png" alt="">
                    <div class="content">
                        <h6>In Stock</h6>
                        <p>Today</p>
                    </div>
                </div>
                <div class="block">
                    <img src="../img/Guaranteed.png" alt="">
                    <div class="content">
                        <h6>Guaranteed</h6>
                        <p>1 year</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="details">
        <div class="content container">
            <h2>Details</h2>
            <p>Just as a book is judged by its cover, the first thing you notice when you pick up a modern smartphone is the display. Nothing surprising, because advanced technologies allow you to practically level the display frames and cutouts for the front camera and speaker, leaving no room for bold design solutions. And how good that in such realities Apple everything is fine with displays. Both critics and mass consumers always praise the quality of the picture provided by the products of the Californian brand. And last year's 6.7-inch Retina panels, which had ProMotion, caused real admiration for many.</p>
            <div class="characteristicsList">
                <div class="characteristicBlock">
                    <h4>Screen</h4>
                    <ul>
                        <li>
                            <p>Screen diagonal<span>6.7"</span></p>
                        </li>
                        <li>
                            <p>The screen resolution<span>2796x1290</span></p>
                        </li>
                        <li>
                            <p>The screen refresh rate<span>120 Hz</span></p>
                        </li>
                        <li>
                            <p>The pixel density<span>460 ppi</span></p>
                        </li>
                        <li>
                            <p>Screen type<span>OLED</span></p>
                        </li>
                        <li>
                            <p>Additionally<span>Dynamic Island<br>Always-On display<br>HDR display<br>True Tone<br>Wide color (P3)</span></p>
                        </li>
                    </ul>
                </div>
                <div class="characteristicBlock">
                    <h4>CPU</h4>
                    <ul>
                        <li>
                            <p>CPU<span>A16 Bionic</span></p>
                        </li>
                        <li>
                            <p>Number of cores<span>6</span></p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="btn-more">
                <a href="#">
                    <button>
                        <p>View More</p>
                        <img src="../img/Expand_down_light.png" alt="">
                    </button>
                </a>
            </div>
        </div>
    </div>

    <div class="reviews container">
        <h2>Reviews</h2>
        <div class="rating">
            <div class="estimation">
                <h1>4.8</h1>
                <p>of 125 reviews</p>
                <div class="stars">
                    <img src="../img/Star.png" alt="">
                    <img src="../img/Star.png" alt="">
                    <img src="../img/Star.png" alt="">
                    <img src="../img/Star.png" alt="">
                    <img src="../img/Star.png" alt="">
                </div>
            </div>
            <div class="ratingScale">
                <div class="rowRating">
                    <h5>Excellent</h5>
                    <img src="../img/Slider.png" alt="">
                    <p>100</p>
                </div>
                <div class="rowRating">
                    <h5>Good</h5>
                    <img src="../img/Slider.png" alt="">
                    <p>11</p>
                </div>
                <div class="rowRating">
                    <h5>Average</h5>
                    <img src="../img/Slider.png" alt="">
                    <p>3</p>
                </div>
                <div class="rowRating">
                    <h5>Below Average</h5>
                    <img src="../img/Slider.png" alt="">
                    <p>8</p>
                </div>
                <div class="rowRating">
                    <h5>Poor</h5>
                    <img src="../img/Slider.png" alt="">
                    <p>1</p>
                </div>
            </div>
        </div>
        <div class="add-comment">
            <form action="" method="post">
                <input type="text" name="comment" id="" placeholder="Leave Comment">
                <button>Send</button>
            </form>
        </div>
        <div class="comments">
            <div class="comment">
                <div class="photo">
                    <img src="../img/UserComment.png" alt="">
                </div>
                <div class="content">
                    <div class="top">
                        <h4>Grace Carey</h4>
                        <p>24 January,2023</p>
                    </div>
                    <div class="ratingUser">
                        <img src="../img/Star.png" alt="">
                        <img src="../img/Star.png" alt="">
                        <img src="../img/Star.png" alt="">
                        <img src="../img/Star.png" alt="">
                        <img src="../img/Star.png" alt="">
                    </div>
                    <div class="textComment">
                        <p>I was a bit nervous to be buying a secondhand phone from Amazon, but I couldn&rsquo;t be happier with my purchase!! I have a pre-paid data plan so I was worried that this phone wouldn&rsquo;t connect with my data plan, since the new phones don&rsquo;t have the physical Sim tray anymore, but couldn&rsquo;t have been easier! I bought an Unlocked black iPhone 14 Pro Max in excellent condition and everything is PERFECT. It was super easy to set up and the phone works and looks great. It truly was in excellent condition. Highly recommend!!!🖤</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="btn-more">
            <a href="#">
                <button>
                    <p>View More</p>
                    <img src="../img/Expand_down_light.png" alt="">
                </button>
            </a>
        </div>
    </div>

<?php
require_once('../lib/footer.php');
?>