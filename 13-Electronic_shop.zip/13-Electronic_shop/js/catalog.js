"use strict";
window.addEventListener("DOMContentLoaded", () => {});

const product = document.querySelectorAll('.likeProduct'); // Массив всех товаров для добавления в избранное
const filterImg = document.querySelectorAll('.filterImg'); //Массив для открытия фильтров в каталоге
const listFilters = document.querySelectorAll('.listFilters'); // Массив списка фильтров
const list_sorting = document.querySelector('.listSorting');
const sort = document.querySelectorAll('.sort');
const openSort = document.querySelector('.openSort');

openSort.addEventListener('click', () => {
    if (openSort.title == 'Открыть сортировку') {
        list_sorting.style.display = 'block';
        openSort.title = 'Скрыть сортировку';
    } else {
        list_sorting.style.display = 'none';
        openSort.title = 'Открыть сортировку';
    }
})

const activelike = (n) => {
    const srcProduct = product[n].src.split('/');
    if (srcProduct[srcProduct.length - 1] == 'Like.png') {
        product[n].src='../img/activeLike.png';
        product[n].title='Не нравится';
    } else {
        product[n].src='../img/Like.png';
        product[n].title='Нравится';
    }
    
}

const openFilter = (x) => {
    if (filterImg[x].classList.contains('rotateImg')) {
        filterImg[x].classList.remove('rotateImg');
        listFilters[x].style.display = 'none';
    } else {
        filterImg[x].classList.add('rotateImg');
        listFilters[x].style.display = 'block';
    } 
}




